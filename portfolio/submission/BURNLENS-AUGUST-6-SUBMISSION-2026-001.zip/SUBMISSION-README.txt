BURNLENS AUGUST 6 PORTFOLIO SUBMISSION
=====================================

1. Extract the complete ZIP.
2. Open START-HERE.html in a current browser.
3. Follow the three-step, two-minute reviewer path.
4. Use the linked quickstart, case study, decisions, and audit for depth.

The bundle is local and offline. Do not open files from inside the ZIP.
No Python environment, provider account, credential, or network is required.

BOUNDARY
Owner-approved regions are prototype evidence, not independent ground truth.
No accepted dataset, split, baseline, model, accuracy, or inference exists.
BurnLens is not official, endorsed, field-validated, operational, or
emergency-ready. Official sources govern.

Source release: v0.48.0-portfolio-reviewer-experience
Source commit: 05140217066277b254e78abb74cd8f61295449d0
Bundle run: BL-2026-07-24-august6-submission-bundle-r002
Generated UTC: 2026-07-24T04:30:00Z
